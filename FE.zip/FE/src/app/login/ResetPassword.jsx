import React from 'react'

export default function ResetPassword() {
  return (
    <div>ResetPassword</div>
  )
}

