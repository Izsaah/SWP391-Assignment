import React from 'react'

export default function ForgotPassword() {

    


  return (
    <div>ForgotPassword</div>
  )
}
